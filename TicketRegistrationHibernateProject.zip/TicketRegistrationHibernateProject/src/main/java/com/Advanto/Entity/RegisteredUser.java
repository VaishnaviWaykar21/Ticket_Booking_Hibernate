package com.Advanto.Entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class RegisteredUser {

	@Id
	long aadharno;
	String name;
	int age;
	String bordingpoint;
	String destinationpoint;
	@Temporal(value = TemporalType.DATE)
	Date dateofDeparture;
	boolean payment;
	
	
	public RegisteredUser(long aadharno, String name, int age, String bordingpoint, String destinationpoint,
			Date dateofDeparture, boolean payment) {
		super();
		this.aadharno = aadharno;
		this.name = name;
		this.age = age;
		this.bordingpoint = bordingpoint;
		this.destinationpoint = destinationpoint;
		this.dateofDeparture = dateofDeparture;
		this.payment = payment;
	}


	public RegisteredUser() {
		super();
		
	}


	public long getAadharno() {
		return aadharno;
	}


	public void setAadharno(long aadharno) {
		this.aadharno = aadharno;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getBordingpoint() {
		return bordingpoint;
	}


	public void setBordingpoint(String bordingpoint) {
		this.bordingpoint = bordingpoint;
	}


	public String getDestinationpoint() {
		return destinationpoint;
	}


	public void setDestinationpoint(String destinationpoint) {
		this.destinationpoint = destinationpoint;
	}


	public Date getDateofDeparture() {
		return dateofDeparture;
	}


	public void setDateofDeparture(Date dateofDeparture) {
		this.dateofDeparture = dateofDeparture;
	}


	public boolean isPayment() {
		return payment;
	}


	public void setPayment(boolean payment) {
		this.payment = payment;
	}


	@Override
	public String toString() {
		return "RegisteredUser [aadharno=" + aadharno + ", name=" + name + ", age=" + age + ", bordingpoint="
				+ bordingpoint + ", destinationpoint=" + destinationpoint + ", dateofDeparture=" + dateofDeparture
				+ ", payment=" + payment + "]";
	}
	
	
	
}
