package com.Advanto.UnImplemented;

import com.Advanto.Entity.User;

public interface TRPInterface {

	public void login();
	
	public void showBuses();
	
	public void bookTicket();
	
	public  void viewTicket();
	
	public User updateInfo();
	
	public void cancelTicket();
	
	public void logout();
}
