package com.Advanto.Implemented;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.Advanto.Entity.Buses;
import com.Advanto.Entity.RegisteredUser;
import com.Advanto.Entity.User;
import com.Advanto.UnImplemented.TRPInterface;
import com.Advento.Configuration.Connection;

public class TRPClass implements TRPInterface{

	Scanner sc = new Scanner(System.in);
	SessionFactory sf  = Connection.connect();
	
	@Override
	public void login() {
		
		System.out.println("Enter your name : ");
		String n = sc.next();
		
		System.out.println("Enter your Contact : ");
		long c = sc.nextLong();
		
		System.out.println("Enter Mail ID :  ");
		String e = sc.next();
		
		System.out.println("Enter Password :  ");
		String p = sc.next();
		
		User user1 = new User();
		user1.setId(1);
		user1.setUname(n);
		user1.setConNo(c);
		user1.setEmail(e);
		user1.setPassword(p);
		
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
			session.save(user1);
			System.out.println("You have been registered successfully............!");
		tx.commit();
		session.close();
	}

	@Override
	public void showBuses() {
		Session session = sf.openSession();
		Criteria c1 = session.createCriteria(Buses.class);
		List<Buses> l1 = c1.list();	
		for (Buses res : l1) {
			System.out.println(res);
		}
		session.close();
	}
	
	@Override
	public void bookTicket() {
		System.out.println("Enter your bus choice : ");
		int choice = sc.nextInt();
		
		System.out.println("Enter your Aadhar no. : ");
		long aadhar = sc.nextLong();
		
		System.out.println("Enter your Name : ");
		String n = sc.next();
		
		System.out.println("Enter your Age : ");
		int a = sc.nextInt();
		
		System.out.println("Enter Bording Point : ");
		String b = sc.next();
		
		System.out.println("Enter Destination point: ");
		String d = sc.next();
		
		System.out.println("Enter date of departure :");
		System.out.println("Enter the year :"); 
		int y = sc.nextInt();
		
		y = y-1900;
		
		System.out.println("Enter the month : "); 
		int month = sc.nextInt();
		
		System.out.println("Enter the day : "); 
		int day = sc.nextInt();
		Date date = new Date(y, month, day);
		
		System.out.println("Payment status (true/false) :");
		boolean status = sc.nextBoolean();
		
		RegisteredUser ru = new RegisteredUser(aadhar, n, a, b, d, date, status);
		
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(ru);
		RegisteredUser ticket = session.get(RegisteredUser.class, aadhar);
		
		
		tx.commit();
		session.close();

	}
	
	@Override
	public void viewTicket() {
		
		System.out.println("Enter your Aadhar number: ");
		long a = sc.nextLong();
		
		Session session = sf.openSession();
		RegisteredUser ticket = session.get(RegisteredUser.class, a); 
		
		System.out.println(" Ticket Details");
		System.out.println(ticket.getName());
		System.out.println(ticket.getAge());
		System.out.println(ticket.getAadharno());
		System.out.println(ticket.getBordingpoint());
		System.out.println(ticket.getDestinationpoint());
		System.out.println(ticket.getDateofDeparture());
		System.out.println("Thank you .....!");
		
		session.close();
	}


	@Override
	public User updateInfo() {
		
		System.out.println("Enter info to update");
		
		System.out.println("Enter your Aadhar number: ");
		long a = sc.nextLong();
		
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		RegisteredUser ru = session.get(RegisteredUser.class, a);
		
		boolean flag = true;
		while(flag) {
	        System.out.println("1] Enter 1 for update your name ");
	        System.out.println("2] Enter 2 for update your age");
	        System.out.println("3] Enter 3 for update your date");
	        System.out.println("4] Enter 4 for update your boarding point");
	        System.out.println("5] Enter 5 for update your destination point");
	        System.out.println("6] Enter 6 for Exit");
	        int choice = sc.nextInt();
	        
	        switch(choice) {
	        case 1 :	System.out.println("Enter your Name : ");
						String n = sc.next();
						ru.setName(n);
						session.update(ru);
						
						tx.commit();
						session.close();
						
     				break;
     		
	        case 2 : 	System.out.println("Enter your Age : ");
						int ag = sc.nextInt();
						ru.setAge(ag);
						session.update(ru);
						
						tx.commit();
						session.close();
					break;
		
	        case 3 : 	System.out.println("Enter date of departure :");
						System.out.println("Enter the year :"); 
						int y = sc.nextInt();
			
						y = y-1900;
			
						System.out.println("Enter the month : "); 
						int month = sc.nextInt();
			
						System.out.println("Enter the day : "); 
						int day = sc.nextInt();
						Date date = new Date(y, month, day);
			
				        ru.setDateofDeparture(date);
						session.update(ru);
						
						tx.commit();
						session.close();
					break;
		
	        case 4 :	System.out.println("Enter Bording Point : ");
						String b = sc.next();
			        	ru.setBordingpoint(b);
						session.update(ru);
						
						tx.commit();
						session.close();
					break;
		
	        case 5 :	System.out.println("Enter Destination point: ");
						String d = sc.next();
			        	ru.setDestinationpoint(d);
						session.update(ru);
						
						tx.commit();
						session.close();
						break;

	        case 6 : 
	        		System.out.println("Thank You...............!");
     				flag = false;
     				break;
     		
	        default : System.out.println("Out of Choice...............");
            		break;
	        }
		}
		return null;
	}

	@Override
	public void cancelTicket() {
		System.out.println("Enter your Aadhar number: ");
		long a = sc.nextLong();
		
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		RegisteredUser ru = session.get(RegisteredUser.class, a);
		session.delete(ru);
		
		tx.commit();
		session.close();
	} 
	
	@Override
	public void logout() {
		
		System.out.println("Enter Mail ID :  ");
		String e = sc.next();

		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
			User u = session.get(User.class, e);
			session.delete(u);
			
		tx.commit();
		session.close();
		sf.close();
		
	}
	
}
